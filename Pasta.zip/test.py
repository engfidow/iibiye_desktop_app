import tkinter as tk

class LoadingIndicator(tk.Canvas):
    def __init__(self, master=None, size=40, *args, **kwargs):
        super().__init__(master, width=size, height=size, *args, **kwargs)
        self.size = size
        self.create_oval(0, 0, size, size, outline='gray', width=3)
        self.angle = 0
        self.after(50, self.rotate)

    def rotate(self):
        self.angle += 10
        if self.angle >= 360:
            self.angle = 0
        self.delete('spinner')
        self.create_arc(2, 2, self.size-2, self.size-2, start=self.angle, extent=90, outline='blue', width=3, tags='spinner')
        self.after(50, self.rotate)

# Example usage
root = tk.Tk()
root.title("Loading Indicator")

loading_indicator = LoadingIndicator(root, size=50, bg='white')
loading_indicator.pack(padx=50, pady=50)

root.mainloop()
