import customtkinter as ctk
from tkinter import ttk
import tkinter as tk
from PIL import Image, ImageTk

from customtkinter import CTkImage
import qrcode

# Configure CustomTkinter appearance and color theme
ctk.set_appearance_mode("Light")  # Set appearance mode to "Light"
ctk.set_default_color_theme("blue")  # Default is "blue"

class SelfCheckoutSystem(ctk.CTk):
    def __init__(self):
       super().__init__()
       self.title("Self-Checkout System")
       # Manually set the window size to the screen size for a maximized effect
       screen_width = self.winfo_screenwidth()
       screen_height = self.winfo_screenheight()
       self.geometry(f"{screen_width}x{screen_height}+0+0")
       # Set background color for areas not covered by CTk widgets
       self.configure(bg_color="#F6F7FB")
       
       self.products = [
            {"Uid": "001", "Name": "Milk", "Price": 1.99, "Image": "scan.png"},
            {"Uid": "002", "Name": "Bread", "Price": 2.49, "Image": "scan.png"},
            {"Uid": "003", "Name": "Cheese", "Price": 3.49, "Image": "scan.png"}
        ]
       self.photo_images = {}
       self.scanned_products = []
       self.start_screen()

    def clear_window(self):
        for widget in self.winfo_children():
            widget.destroy()
    
    def animate_gif(self, label, gif_file):
        gif = Image.open(gif_file)
        self.gif_frames = []  # Initialize the list to hold the frames
        try:
            for frame_num in range(gif.n_frames):
                gif.seek(frame_num)
                # Resize the current frame. Adjust (width, height) as needed.
                # Use Image.Resampling.LANCZOS for high-quality downsampling
                resized_frame = gif.copy().resize((850, 850), Image.Resampling.LANCZOS)  # Resize to 150x150
                frame_image = ImageTk.PhotoImage(resized_frame)  # Create a PhotoImage from the resized frame
                self.gif_frames.append(frame_image)
        except EOFError:
            pass  # The end of the GIF file has been reached

        self.gif_index = 0  # Starting index
        self.update_gif(label)


    def update_gif(self, label):
        frame = self.gif_frames[self.gif_index]
        label.config(image=frame)
        self.gif_index = (self.gif_index + 1) % len(self.gif_frames)  # Loop the index
        label.after(20, self.update_gif, label)  # Update every 20ms

    def start_screen(self):
        self.clear_window()
        full_screen_frame = ctk.CTkFrame(self, fg_color="#F6F7FB", corner_radius=0)
        full_screen_frame.pack(expand=True, fill='both')

        # Adjust padding to ensure all elements are visible
        center_frame = ctk.CTkFrame(full_screen_frame, fg_color="#F6F7FB", corner_radius=10)
        center_frame.pack(expand=True, padx=20, pady=20)

        prompt_label = ctk.CTkLabel(center_frame, text="Place Items & Click Start Button To Start Checkout",
                                    font=("Arial", 30,"bold"), fg_color="#F6F7FB", text_color="black")
        prompt_label.pack(pady=10)

        # Add GIF animation
        gif_label = tk.Label(center_frame, bg="#F6F7FB")
        gif_label.pack(pady=10)
        self.animate_gif(gif_label, "check_start.gif")

        # Button for starting the scan
        scan_button = ctk.CTkButton(center_frame, text="Start", command=self.scan_product,
                                     corner_radius=20, fg_color="#F40000",font=("Arial", 20), hover_color="#C10000")
        scan_button.pack(pady=10)




    def scan_product(self):
        # Simulate scanning by adding all products to the scanned list
        # self.scanned_products.extend([(Image, Uid, name, price) for Image, Uid ,name, price in self.products()])
        self.scanned_products = self.products.copy()
        self.display_cart()

    def display_cart(self):
        self.clear_window()
        # Set a smaller padding for the outer frame to give more space to the table
        cart_frame = ctk.CTkFrame(self, fg_color="#F6F7FB", corner_radius=0)
        cart_frame.pack(expand=True, fill='both')

        # Title label for the cart
        title_label = ctk.CTkLabel(cart_frame, text="Your List of Products", font=("Arial", 24, "bold"), fg_color="#F6F7FB", text_color="black")
        title_label.pack(pady=20)

        # Treeview Style
        style = ttk.Style()
        style.theme_use("clam")  # A theme with a modern look
        style.configure("Treeview",
                        background="white",
                        foreground="black",
                        rowheight=35,  # Increase row height for better visibility
                        fieldbackground="white")
        style.map('Treeview', background=[('selected', '#E0E0E0')])  # Change selection background color
        style.configure("Treeview.Heading", background="#F40000", font=("Arial", 30, "bold"), foreground="white")  # Larger font for headings
        style.configure("Treeview", font=("Arial", 20))  # Larger font for content
        style.configure("Treeview",
                background="white",
                foreground="black",
                rowheight=100,  # Adjust this value as necessary to fit the images
                fieldbackground="white")


        # Scrollbar style
        style.configure("Vertical.TScrollbar", background="#F40000", troughcolor="#F6F7FB")

        # Centered frame for the treeview table with less padding to allow for a larger table
        table_frame = ctk.CTkFrame(cart_frame, fg_color="#F6F7FB", corner_radius=10)
        table_frame.pack(expand=True, fill='both', padx=100, pady=30)

        # Create the scrollable Treeview for cart items
        tree_scroll = ttk.Scrollbar(table_frame, style="Vertical.TScrollbar")
        tree_scroll.pack(side='right', fill='y')

        cart_table = ttk.Treeview(table_frame, yscrollcommand=tree_scroll.set, columns=('Image', 'Name', 'Price'), show='headings')
        cart_table.pack(expand=True, fill='both')

        # Configure each column
        cart_table.column("Image", anchor=tk.CENTER, width=100)  # Adjust width as needed for the image
        cart_table.column("Name", anchor=tk.W, stretch=tk.YES)
        cart_table.column("Price", anchor=tk.W, stretch=tk.YES)
        
        # Configure each column's heading
        cart_table.heading("Image", text="Image", anchor=tk.CENTER)
        cart_table.heading("Name", text="Name", anchor=tk.W)
        cart_table.heading("Price", text="Price", anchor=tk.W)

        tree_scroll.config(command=cart_table.yview)
        
       
        
        for product in self.scanned_products:
            img_path = product['Image']
            try:
                pil_image = Image.open(img_path).resize((50, 50), Image.Resampling.LANCZOS)
                photo = ImageTk.PhotoImage(pil_image)
                # Using the product Uid as the key for the dictionary
                self.photo_images[product['Uid']] = photo
                item = cart_table.insert('', 'end', values=(photo, product['Name'], f"${product['Price']:0.2f}"))
                # Retrieve the image using the product Uid and assign it to the Treeview item
                cart_table.item(item, image=self.photo_images[product['Uid']])
               
            except IOError as e:
                print(f"Error: Failed to open or process image file {img_path} with error {e}")



        # Positioning the total and buy button
        total_price = sum(product['Price'] for product in self.scanned_products)
        total_label = ctk.CTkLabel(cart_frame, text=f"Total Price: ${total_price:.2f}", font=("Arial", 20), fg_color="#F6F7FB", text_color="black")
        total_label.pack(side='left', padx=200, pady=70)

        buy_button = ctk.CTkButton(cart_frame, text="Buy", command=self.generate_qr_code, corner_radius=20, fg_color="#F40000", hover_color="#C10000", font=("Arial", 16))

        buy_button.pack(side='right', padx=200, pady=70)



    def generate_qr_code(self):
        qr_info = "\n".join([f"{name}: ${price}" for name, price in self.scanned_products])
        qr_info += f"\nTotal: ${sum(price for _, price in self.scanned_products):.2f}"
        qr = qrcode.make(qr_info)
        qr.save("payment_qr.png")  # Save the QR code as an image file
        self.display_qr_code()
    
    def animate_scan(self, label, gif_file):
        gif = Image.open(gif_file)
        self.gif_frames = []  # Initialize the list to hold the frames
        try:
            for frame_num in range(gif.n_frames):
                gif.seek(frame_num)
                # Resize the current frame. Adjust (width, height) as needed.
                # Use Image.Resampling.LANCZOS for high-quality downsampling
                resized_frame = gif.copy().resize((850, 850), Image.Resampling.LANCZOS)  # Resize to 150x150
                frame_image = ImageTk.PhotoImage(resized_frame)  # Create a PhotoImage from the resized frame
                self.gif_frames.append(frame_image)
        except EOFError:
            pass  # The end of the GIF file has been reached

        self.gif_index = 0  # Starting index
        self.update_scan(label)


    def update_scan(self, label):
        frame = self.gif_frames[self.gif_index]
        label.config(image=frame)
        self.gif_index = (self.gif_index + 1) % len(self.gif_frames)  # Loop the index
        label.after(20, self.update_scan, label)  # Update every 20ms

    def display_qr_code(self):
        self.clear_window()
        qr_frame = ctk.CTkFrame(self, fg_color="#F6F7FB", corner_radius=0)
        qr_frame.pack(expand=True, fill='both')

        # Create a frame to hold both QR and GIF side by side, centered
        row_frame = ctk.CTkFrame(qr_frame, fg_color="#F6F7FB")
        row_frame.pack(pady=130)

        # Display the additional image to the left using tk.Label
        scan_image_pil = Image.open("scan.png")  # Make sure this image file exists
        scan_photo = ImageTk.PhotoImage(scan_image_pil.resize((550, 450), Image.Resampling.LANCZOS))
        scan_label = tk.Label(row_frame, image=scan_photo, bg="#F6F7FB")  # Using tk.Label here
        scan_label.image = scan_photo  # Keep a reference
        scan_label.pack(side='left', padx=10)

        # Display the QR code to the right using tk.Label
        qr_image_pil = Image.open("payment_qr.png")
        qr_photo = ImageTk.PhotoImage(qr_image_pil.resize((550, 550), Image.Resampling.LANCZOS))
        qr_label = tk.Label(row_frame, image=qr_photo, bg="#F6F7FB")  # Using tk.Label here
        qr_label.image = qr_photo  # Keep a reference
        qr_label.pack(side='right', padx=10)

       

        # Instruction label below the row frame
        instruction_label = ctk.CTkLabel(qr_frame, text="Download the Retail Flash App Payment from the Play Store or App Store, and scan the QR code.", font=("Arial", 16), fg_color="#F6F7FB", text_color="black")
        instruction_label.pack(pady=10)

        # "Back" button to return to the cart, placed below the instruction label
        back_button = ctk.CTkButton(qr_frame, text="Back", command=self.display_cart, corner_radius=10, fg_color="#F40000", hover_color="#C10000", font=("Arial", 16))
        back_button.pack(pady=10)

if __name__ == "__main__":
    app = SelfCheckoutSystem()
    app.mainloop()
